from django.contrib import admin
from .models import Entreprise,Notification
# Register your models here.


admin.site.register(Entreprise)

